"""school URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,re_path
from django.views.static import serve

from app.views import *
from school.settings import MEDIA_ROOT

urlpatterns = [
    path('admin/', admin.site.urls),
    # path('',admin.site.urls),
    path('networks',networks),
    path("getalldata",getalldata),
    path("getdata", getdata),
    path("exam",startExam),
    path("radar_aqi",radar_aqi),
    path("calGrade",calGrade),
    path("dina",dina),
    # path(r'^networks',views.networks),
    # path(r'^startExam/$',views.startExam)
    path("article_index",article_index),
    re_path(r'^media/(?P<path>.*)$', serve, {"document_root" : MEDIA_ROOT}),
    re_path('article_detail/(\d)/',article_detail),  #文章详情页路由，并传入文章的id
    path('comment_control/',comment_control),   #提交评论处理的路由
    path('fileshow/',file_show),   #提交评论处理的路由
    path('student_info/',student_info),   #提交评论处理的路由
    path('plot_student_scores/',plot_student_scores),
    # path('get_student_scores/',views.get_student_scores),
    path('sort_key',sort_key),
    path("regist",regist),
    # /article_predict
    # path('article_predict/',views.article_predict)   #提交评论处理的路由
]
