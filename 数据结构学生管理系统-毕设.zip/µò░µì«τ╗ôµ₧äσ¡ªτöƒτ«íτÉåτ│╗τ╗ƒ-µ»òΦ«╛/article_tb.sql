/*
 Navicat Premium Data Transfer

 Source Server         : data
 Source Server Type    : SQLite
 Source Server Version : 3035005 (3.35.5)
 Source Schema         : main

 Target Server Type    : SQLite
 Target Server Version : 3035005 (3.35.5)
 File Encoding         : 65001

 Date: 01/04/2024 03:34:51
*/

PRAGMA foreign_keys = false;

-- ----------------------------
-- Table structure for article_tb
-- ----------------------------
DROP TABLE IF EXISTS "article_tb";
CREATE TABLE "article_tb" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "title" varchar(100) NOT NULL,
  "content" text NOT NULL,
  "publish_time" datetime NOT NULL,
  "author_id" integer NOT NULL,
  "question" text NOT NULL,
  FOREIGN KEY ("author_id") REFERENCES "auth_user" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED
);

-- ----------------------------
-- Table structure for comment_tb
-- ----------------------------
DROP TABLE IF EXISTS "comment_tb";
CREATE TABLE "comment_tb" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "comment_content" text NOT NULL,
  "comment_time" datetime NOT NULL,
  "article_id" bigint NOT NULL,
  "comment_author_id" integer NOT NULL,
  "pre_comment_id" bigint,
  FOREIGN KEY ("article_id") REFERENCES "article_tb" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED,
  FOREIGN KEY ("comment_author_id") REFERENCES "auth_user" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED,
  FOREIGN KEY ("pre_comment_id") REFERENCES "comment_tb" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED
);

-- ----------------------------
-- Table structure for file_Input
-- ----------------------------
DROP TABLE IF EXISTS "file_Input";
CREATE TABLE "file_Input" (
  "uuid" char(32) NOT NULL,
  "name" varchar(100) NOT NULL,
  "img_file" varchar(100) NOT NULL,
  "study_type" varchar(10) NOT NULL,
  "file" varchar(255) NOT NULL,
  "user_id" char(32) NOT NULL,
  "desc" text NOT NULL,
  PRIMARY KEY ("uuid"),
  FOREIGN KEY ("user_id") REFERENCES "teacher" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED
);

-- ----------------------------
-- Table structure for file_Input_Knowledge1s
-- ----------------------------
DROP TABLE IF EXISTS "file_Input_Knowledge1s";
CREATE TABLE "file_Input_Knowledge1s" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "file_input_id" char(32) NOT NULL,
  "knowledge1_id" char(32) NOT NULL,
  FOREIGN KEY ("file_input_id") REFERENCES "file_Input" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED,
  FOREIGN KEY ("knowledge1_id") REFERENCES "Knowledge" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED
);

-- ----------------------------
-- Table structure for grade
-- ----------------------------
DROP TABLE IF EXISTS "grade";
CREATE TABLE "grade" (
  "uuid" char(32) NOT NULL,
  "subject" varchar(20) NOT NULL,
  "grade" integer NOT NULL,
  "sid_id" char(32) NOT NULL,
  PRIMARY KEY ("uuid"),
  FOREIGN KEY ("sid_id") REFERENCES "student" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED
);

-- ----------------------------
-- Table structure for Knowledge
-- ----------------------------
DROP TABLE IF EXISTS "Knowledge";
CREATE TABLE "Knowledge" (
  "uuid" char(32) NOT NULL,
  "type" varchar(100) NOT NULL,
  "name" varchar(100) NOT NULL,
  "desc" varchar(100),
  "desc_all" varchar(1000),
  PRIMARY KEY ("uuid")
);

-- ----------------------------
-- Table structure for paper
-- ----------------------------
DROP TABLE IF EXISTS "paper";
CREATE TABLE "paper" (
  "uuid" char(32) NOT NULL,
  "subject" varchar(20) NOT NULL,
  "major" varchar(20) NOT NULL,
  "examtime" datetime NOT NULL,
  "stoptime" datetime NOT NULL,
  "tid_id" char(32) NOT NULL,
  PRIMARY KEY ("uuid"),
  FOREIGN KEY ("tid_id") REFERENCES "teacher" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED
);

-- ----------------------------
-- Table structure for paper_pid
-- ----------------------------
DROP TABLE IF EXISTS "paper_pid";
CREATE TABLE "paper_pid" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "paper_id" char(32) NOT NULL,
  "question_id" char(32) NOT NULL,
  FOREIGN KEY ("paper_id") REFERENCES "paper" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED,
  FOREIGN KEY ("question_id") REFERENCES "question" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED
);

-- ----------------------------
-- Table structure for paper_sid
-- ----------------------------
DROP TABLE IF EXISTS "paper_sid";
CREATE TABLE "paper_sid" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "paper_id" char(32) NOT NULL,
  "student_id" char(32) NOT NULL,
  FOREIGN KEY ("paper_id") REFERENCES "paper" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED,
  FOREIGN KEY ("student_id") REFERENCES "student" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED
);

-- ----------------------------
-- Table structure for question
-- ----------------------------
DROP TABLE IF EXISTS "question";
CREATE TABLE "question" (
  "uuid" char(32) NOT NULL,
  "subject" varchar(20) NOT NULL,
  "title" text NOT NULL,
  "optionA" varchar(30) NOT NULL,
  "optionB" varchar(30) NOT NULL,
  "optionC" varchar(30) NOT NULL,
  "optionD" varchar(30) NOT NULL,
  "answer" varchar(10) NOT NULL,
  "level" varchar(10) NOT NULL,
  "score" integer NOT NULL,
  PRIMARY KEY ("uuid")
);

-- ----------------------------
-- Table structure for question_Knowledge
-- ----------------------------
DROP TABLE IF EXISTS "question_Knowledge";
CREATE TABLE "question_Knowledge" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "question_id" char(32) NOT NULL,
  "knowledge1_id" char(32) NOT NULL,
  FOREIGN KEY ("question_id") REFERENCES "question" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED,
  FOREIGN KEY ("knowledge1_id") REFERENCES "Knowledge" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED
);

-- ----------------------------
-- Table structure for Rel
-- ----------------------------
DROP TABLE IF EXISTS "Rel";
CREATE TABLE "Rel" (
  "uuid" char(32) NOT NULL,
  "rel_name" varchar(100) NOT NULL,
  "rel_type" varchar(300) NOT NULL,
  "obj_name_id" char(32) NOT NULL,
  "sub_name_id" char(32) NOT NULL,
  PRIMARY KEY ("uuid"),
  FOREIGN KEY ("obj_name_id") REFERENCES "Knowledge" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED,
  FOREIGN KEY ("sub_name_id") REFERENCES "Knowledge" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED
);

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS "student";
CREATE TABLE "student" (
  "uuid" char(32) NOT NULL,
  "name" varchar(20) NOT NULL,
  "class_name" varchar(20) NOT NULL,
  "sex" varchar(4) NOT NULL,
  "dept" varchar(20) NOT NULL,
  "user_id" integer NOT NULL,
  "major" varchar(20) NOT NULL,
  PRIMARY KEY ("uuid"),
  FOREIGN KEY ("user_id") REFERENCES "auth_user" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED
);

-- ----------------------------
-- Table structure for study_Knowledge1
-- ----------------------------
DROP TABLE IF EXISTS "study_Knowledge1";
CREATE TABLE "study_Knowledge1" (
  "uuid" char(32) NOT NULL,
  "score" varchar(10) NOT NULL,
  "knowledge_id" char(32) NOT NULL,
  "sid_id" char(32) NOT NULL,
  PRIMARY KEY ("uuid"),
  FOREIGN KEY ("knowledge_id") REFERENCES "Knowledge" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED,
  FOREIGN KEY ("sid_id") REFERENCES "student" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED
);

-- ----------------------------
-- Table structure for study_Question
-- ----------------------------
DROP TABLE IF EXISTS "study_Question";
CREATE TABLE "study_Question" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "score" varchar(10) NOT NULL,
  "paper_id" char(32) NOT NULL,
  "que_id" char(32) NOT NULL,
  "sid_id" char(32) NOT NULL,
  FOREIGN KEY ("paper_id") REFERENCES "paper" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED,
  FOREIGN KEY ("que_id") REFERENCES "question" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED,
  FOREIGN KEY ("sid_id") REFERENCES "student" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED
);

-- ----------------------------
-- Table structure for study_type
-- ----------------------------
DROP TABLE IF EXISTS "study_type";
CREATE TABLE "study_type" (
  "uuid" char(32) NOT NULL,
  "study1" varchar(20) NOT NULL,
  "study2" varchar(20) NOT NULL,
  "study3" varchar(20) NOT NULL,
  "study4" varchar(20) NOT NULL,
  "study_max" varchar(20) NOT NULL,
  "study_type" varchar(20) NOT NULL,
  "sid_id" char(32) NOT NULL,
  PRIMARY KEY ("uuid"),
  FOREIGN KEY ("sid_id") REFERENCES "student" ("uuid") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED
);

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS "teacher";
CREATE TABLE "teacher" (
  "uuid" char(32) NOT NULL,
  "name" varchar(20) NOT NULL,
  "sex" varchar(4) NOT NULL,
  "dept" varchar(20) NOT NULL,
  "user_id" integer NOT NULL,
  PRIMARY KEY ("uuid"),
  FOREIGN KEY ("user_id") REFERENCES "auth_user" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED
);

-- ----------------------------
-- Auto increment value for article_tb
-- ----------------------------
UPDATE "sqlite_sequence" SET seq = 2 WHERE name = 'article_tb';

-- ----------------------------
-- Indexes structure for table article_tb
-- ----------------------------
CREATE INDEX "article_tb_author_id_8c5527d4"
ON "article_tb" (
  "author_id" ASC
);

-- ----------------------------
-- Auto increment value for comment_tb
-- ----------------------------
UPDATE "sqlite_sequence" SET seq = 6 WHERE name = 'comment_tb';

-- ----------------------------
-- Indexes structure for table comment_tb
-- ----------------------------
CREATE INDEX "comment_tb_article_id_360b030c"
ON "comment_tb" (
  "article_id" ASC
);
CREATE INDEX "comment_tb_comment_author_id_dd49c0c2"
ON "comment_tb" (
  "comment_author_id" ASC
);
CREATE INDEX "comment_tb_pre_comment_id_5af5c386"
ON "comment_tb" (
  "pre_comment_id" ASC
);

-- ----------------------------
-- Indexes structure for table file_Input
-- ----------------------------
CREATE INDEX "file_Input_user_id_28fb729b"
ON "file_Input" (
  "user_id" ASC
);

-- ----------------------------
-- Auto increment value for file_Input_Knowledge1s
-- ----------------------------
UPDATE "sqlite_sequence" SET seq = 36 WHERE name = 'file_Input_Knowledge1s';

-- ----------------------------
-- Indexes structure for table file_Input_Knowledge1s
-- ----------------------------
CREATE INDEX "file_Input_Knowledge1s_file_input_id_205659c8"
ON "file_Input_Knowledge1s" (
  "file_input_id" ASC
);
CREATE UNIQUE INDEX "file_Input_Knowledge1s_file_input_id_knowledge1_id_7cee31ad_uniq"
ON "file_Input_Knowledge1s" (
  "file_input_id" ASC,
  "knowledge1_id" ASC
);
CREATE INDEX "file_Input_Knowledge1s_knowledge1_id_d85b5d15"
ON "file_Input_Knowledge1s" (
  "knowledge1_id" ASC
);

-- ----------------------------
-- Indexes structure for table grade
-- ----------------------------
CREATE INDEX "grade_sid_id_7de9086e"
ON "grade" (
  "sid_id" ASC
);

-- ----------------------------
-- Indexes structure for table paper
-- ----------------------------
CREATE INDEX "paper_tid_id_ddacd8df"
ON "paper" (
  "tid_id" ASC
);

-- ----------------------------
-- Auto increment value for paper_pid
-- ----------------------------
UPDATE "sqlite_sequence" SET seq = 190 WHERE name = 'paper_pid';

-- ----------------------------
-- Indexes structure for table paper_pid
-- ----------------------------
CREATE INDEX "paper_pid_paper_id_56658225"
ON "paper_pid" (
  "paper_id" ASC
);
CREATE UNIQUE INDEX "paper_pid_paper_id_question_id_566d3fd0_uniq"
ON "paper_pid" (
  "paper_id" ASC,
  "question_id" ASC
);
CREATE INDEX "paper_pid_question_id_066d7dbd"
ON "paper_pid" (
  "question_id" ASC
);

-- ----------------------------
-- Auto increment value for paper_sid
-- ----------------------------
UPDATE "sqlite_sequence" SET seq = 1610 WHERE name = 'paper_sid';

-- ----------------------------
-- Indexes structure for table paper_sid
-- ----------------------------
CREATE INDEX "paper_sid_paper_id_8b3eb026"
ON "paper_sid" (
  "paper_id" ASC
);
CREATE UNIQUE INDEX "paper_sid_paper_id_student_id_cfbe53aa_uniq"
ON "paper_sid" (
  "paper_id" ASC,
  "student_id" ASC
);
CREATE INDEX "paper_sid_student_id_e9b8f0f3"
ON "paper_sid" (
  "student_id" ASC
);

-- ----------------------------
-- Auto increment value for question_Knowledge
-- ----------------------------
UPDATE "sqlite_sequence" SET seq = 324 WHERE name = 'question_Knowledge';

-- ----------------------------
-- Indexes structure for table question_Knowledge
-- ----------------------------
CREATE INDEX "question_Knowledge_knowledge1_id_3e63f5ff"
ON "question_Knowledge" (
  "knowledge1_id" ASC
);
CREATE INDEX "question_Knowledge_question_id_7d3d1d05"
ON "question_Knowledge" (
  "question_id" ASC
);
CREATE UNIQUE INDEX "question_Knowledge_question_id_knowledge1_id_0e201ec4_uniq"
ON "question_Knowledge" (
  "question_id" ASC,
  "knowledge1_id" ASC
);

-- ----------------------------
-- Indexes structure for table Rel
-- ----------------------------
CREATE INDEX "Rel_obj_name_id_dc55a601"
ON "Rel" (
  "obj_name_id" ASC
);
CREATE INDEX "Rel_sub_name_id_02a3488b"
ON "Rel" (
  "sub_name_id" ASC
);

-- ----------------------------
-- Indexes structure for table student
-- ----------------------------
CREATE INDEX "student_user_id_dcc2526f"
ON "student" (
  "user_id" ASC
);

-- ----------------------------
-- Indexes structure for table study_Knowledge1
-- ----------------------------
CREATE INDEX "study_Knowledge1_knowledge_id_0d7ed7a6"
ON "study_Knowledge1" (
  "knowledge_id" ASC
);
CREATE INDEX "study_Knowledge1_sid_id_2e6c16a1"
ON "study_Knowledge1" (
  "sid_id" ASC
);

-- ----------------------------
-- Auto increment value for study_Question
-- ----------------------------
UPDATE "sqlite_sequence" SET seq = 43710 WHERE name = 'study_Question';

-- ----------------------------
-- Indexes structure for table study_Question
-- ----------------------------
CREATE INDEX "study_Question_paper_id_1517ba92"
ON "study_Question" (
  "paper_id" ASC
);
CREATE INDEX "study_Question_que_id_5841046e"
ON "study_Question" (
  "que_id" ASC
);
CREATE INDEX "study_Question_sid_id_4425bfe6"
ON "study_Question" (
  "sid_id" ASC
);

-- ----------------------------
-- Indexes structure for table study_type
-- ----------------------------
CREATE INDEX "study_type_sid_id_6adb67a6"
ON "study_type" (
  "sid_id" ASC
);

-- ----------------------------
-- Indexes structure for table teacher
-- ----------------------------
CREATE INDEX "teacher_user_id_e6b0eb7c"
ON "teacher" (
  "user_id" ASC
);

PRAGMA foreign_keys = true;
