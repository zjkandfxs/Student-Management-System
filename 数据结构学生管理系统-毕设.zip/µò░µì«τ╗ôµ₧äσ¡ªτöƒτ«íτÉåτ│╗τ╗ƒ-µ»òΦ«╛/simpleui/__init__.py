default_app_config = 'simpleui.apps.SimpleApp'


def get_version():
    return '2022.7.29'
