# _*_ coding:utf-8 _*_
"""
@File     : form.py
@Project  : school
@Time     : 2022/12/18 22:08
@Author   : KUN
@Software : PyCharm
@License  : (C)Copyright 2018-2028, Taogroup-NLPR-CASIA
@Last Modify Time      @Version     @Desciption
--------------------       --------        -----------
2022/12/18 22:08        1.0             None
"""

# from django import forms
# from .models import *
#
# class ArticleFrom(forms.ModelForm):
#     class Meta:
#         model = Article
#         fields = "__all__"
#
#     def __init__(self, *args, **kwargs):
#         super(ArticleFrom,self).__init__(*args,**kwargs)


