from django.contrib import admin
from django.contrib.auth.models import User

admin.site.site_header='欢迎使用知识图谱学习助手'
admin.site.site_title='知识图谱学习助手'
# Register your models here.

from .models import Student, Teacher, Paper, Question, Grade, study_type, Knowledge1, Rel, study_Knowledge1, \
    study_Question, file_Input, Article, Comment


@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    def get_queryset(self, request):  # 自允许查看修改与自己相关的
        qs = super(StudentAdmin, self).get_queryset(request)
        if request.user.is_superuser:
            return qs
        return qs.filter(user=request.user)

    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == 'student':
            # print(db_field)
            kwargs['initial'] = Student.objects.get(user=request.user).uuid
            kwargs['disabled'] = True
        return super(StudentAdmin, self).formfield_for_foreignkey(db_field, request, **kwargs)

    list_display = ('name','sex','dept','major')# 要显示哪些信息
    list_display_links = ('name',)#点击哪些信息可以进入编辑页面
    search_fields = ['name','dept','major']   #指定要搜索的字段，将会出现一个搜索框让管理员搜索关键词
    list_filter =['name','dept','major']#指定列表过滤器，右边将会出现一个快捷的过滤选项

@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    def get_queryset(self, request):  # 自允许查看修改与自己相关的
        qs = super(TeacherAdmin, self).get_queryset(request)
        if request.user.is_superuser:
            return qs
        return qs.filter(user=request.user)

    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == 'teacher':
            # print(db_field)
            kwargs['initial'] = Teacher.objects.get(user=request.user).uuid
            kwargs['disabled'] = True
        return super(TeacherAdmin, self).formfield_for_foreignkey(db_field, request, **kwargs)

    list_display = ( 'name', 'sex', 'dept')
    list_display_links = ( 'name',)
    search_fields = ['name', 'dept',]
    list_filter = ['name','dept']

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ('subject','title','optionA','optionB','optionC','optionD','answer','level','score','Knowledge')
    def Knowledge(self,obj):
        return [bt.name for bt in obj.Knowledge.all()]
    filter_horizontal = ('Knowledge',)

@admin.register(Paper)
class PaperAdmin(admin.ModelAdmin):
    list_display = ('pid','sid','tid','major','subject','examtime')
    list_display_links = ('major','subject','examtime')
    def pid(self,obj):
        return [bt.name for bt in obj.pid.all()]
    def sid(self,obj):
        return [bt.name for bt in obj.sid.all()]
    filter_horizontal = ('pid','sid')
    # 57b9d4cb-651d-4b94-8627-ed8b54c9f0e5
@admin.register(Grade)
class GradeAdmin(admin.ModelAdmin):
    list_display = ('sid','subject','grade',)
    list_display_links = ('sid','subject','grade',)

    # fk_fields = ['sid']

@admin.register(study_type)
class study_typeAdmin(admin.ModelAdmin):
    list_display = ('sid', 'study1', 'study2','study3','study4','study_max','study_type')
    list_display_links = ('sid', 'study1', 'study2','study3','study4','study_max','study_type')
    search_fields = ['sid', 'study1', 'study2','study3','study4','study_max','study_type']
    list_filter = ['sid', 'study1', 'study2','study3','study4','study_max','study_type']

@admin.register(Knowledge1)
class Knowledge1Admin(admin.ModelAdmin):
    list_display = ('type','name','desc')# ,'child'

@admin.register(Rel)
class RelAdmin(admin.ModelAdmin):
    list_display = ('obj_name', 'sub_name','rel_name','rel_type')

@admin.register(study_Question)
class study_QuestionAdmin(admin.ModelAdmin):
    list_display = ('sid','que','score')

@admin.register(study_Knowledge1)
class study_Knowledge1Admin(admin.ModelAdmin):
    list_display = ('sid','knowledge','score')

@admin.register(file_Input)
class file_InputAdmin(admin.ModelAdmin):
    list_display = ('name','img_file','study_type','Knowledge1s','file',"user")
    def Knowledge1s(self,obj):
        return [bt.name for bt in obj.Knowledge1s.all()]
    filter_horizontal = ('Knowledge1s',)

    def queryset(self, request):
        if request.user.is_superuser:
            return file_Input.objects.all()
        return file_Input.objects.filter(user=request.user)

    def save_model(self, request, obj, form, change):
        if not change:
            obj.user = Teacher.objects.get(user=request.user)
        obj.save()


@admin.register(Article)
class ArticleAdmin(admin.ModelAdmin):
    list_display = ("title","content","publish_time",'author','question')
    fieldsets = (
        (None, {
            'fields': ('title', 'content','question'),
            'classes': ('extrapretty',),
        }),
    )
    def get_queryset(self, request):  # 自允许查看修改与自己相关的
        qs = super(ArticleAdmin, self).get_queryset(request)
        if request.user.is_superuser:
            return qs
        return qs.filter(author=request.user)


    def save_model(self, request, obj, form, change):
        if not change:
            obj.author = request.user


        super().save_model(request, obj, form, change)


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ("article", "comment_content", "comment_author", "comment_time",'pre_comment')


