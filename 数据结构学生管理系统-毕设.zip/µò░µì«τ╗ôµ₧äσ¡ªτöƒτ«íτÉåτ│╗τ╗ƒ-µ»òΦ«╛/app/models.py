from django.db import models

# Create your models here.
from django.db import models
from django.contrib.auth.models import User
import uuid
# Create your models here.

# 为性别,学院 指定备选字段
SEX=(
    ('男','男'),
    ('女','女'),
)

class Student(models.Model):
    uuid = models.UUIDField(primary_key=True, verbose_name="uuid", auto_created=True, default=uuid.uuid4,
                            editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    name=models.CharField('姓名',max_length=20)
    class_name = models.CharField('班级', max_length=20)
    sex=models.CharField('性别',max_length=4,choices=SEX,default='男')
    dept=models.CharField('爱好',max_length=20,default=None)
    major=models.CharField('年级',max_length=20,default="大一年级")
    class Meta:
        db_table='student'
        verbose_name='学生'
        verbose_name_plural=verbose_name
    def __str__(self):
        return self.name;

class Teacher(models.Model):
    uuid = models.UUIDField(primary_key=True, verbose_name="uuid", auto_created=True, default=uuid.uuid4,
                            editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    name=models.CharField('姓名',max_length=20)
    sex=models.CharField('性别',max_length=4,choices=SEX,default='男')
    dept=models.CharField('年级',max_length=20)

    class Meta:
        db_table='teacher'
        verbose_name='教师'
        verbose_name_plural=verbose_name
    def __str__(self):
        return self.name;



class Knowledge1(models.Model):
    uuid= models.UUIDField(primary_key=True, verbose_name="uuid", auto_created=True, default=uuid.uuid4,
                            editable=False)
    type = models.CharField("节点类型",max_length=100)
    name = models.CharField("节点名称",max_length=100)
    desc = models.CharField("节点内容",max_length=100,null=True)
    desc_all = models.CharField("详细描述", max_length=1000, null=True)

    class Meta:
        db_table='Knowledge'
        verbose_name='知识点'
        verbose_name_plural=verbose_name
    def __str__(self):
        return self.name;



class Rel(models.Model):
    uuid = models.UUIDField(primary_key=True, verbose_name="uuid", auto_created=True, default=uuid.uuid4,
                            editable=False)
    obj_name = models.ForeignKey(Knowledge1,on_delete=models.CASCADE,related_name="知识点1")
    sub_name = models.ForeignKey(Knowledge1,on_delete=models.CASCADE,related_name="知识点2")
    rel_name = models.CharField("知识点间关系",max_length=100)
    rel_type = models.CharField("知识点间类别",max_length=300)

    class Meta:
        db_table='Rel'
        verbose_name='知识点间关系'
        verbose_name_plural=verbose_name
    def __str__(self):
        return str(self.uuid)

class Question(models.Model):

    ANSWER=(
        ('A','A'),
        ('B','B'),
        ('C','C'),
        ('D','D'),
    )
    LEVEL={
        ('1','easy'),
        ('2','general'),
        ('3','difficult'),
    }
    uuid = models.UUIDField(primary_key=True, verbose_name="uuid", auto_created=True, default=uuid.uuid4,
                            editable=False)
    subject = models.CharField('科目', max_length=20)
    title = models.TextField('题目')
    optionA=models.CharField('A选项',max_length=30)
    optionB=models.CharField('B选项',max_length=30)
    optionC=models.CharField('C选项',max_length=30)
    optionD=models.CharField('D选项',max_length=30)
    answer=models.CharField('答案',max_length=10,choices=ANSWER)
    level=models.CharField('等级',max_length=10,choices=LEVEL)
    score=models.IntegerField('分数',default=1)
    Knowledge = models.ManyToManyField(to=Knowledge1)

    def Knowledge_list(self):
        return ','.join([i.name for i in self.Knowledge.all()])

    class Meta:
        db_table='question'
        verbose_name='单项选择题库'
        verbose_name_plural=verbose_name
    def __str__(self):
        return '<%s:%s>'%(self.subject,self.title);

class Paper(models.Model):
    #题号pid 和题库为多对多的关系
    uuid = models.UUIDField(primary_key=True, verbose_name="uuid", auto_created=True, default=uuid.uuid4,
                            editable=False)
    pid=models.ManyToManyField(Question)#一对多
    tid=models.ForeignKey(Teacher,on_delete=models.CASCADE)#添加外键
    sid = models.ManyToManyField(Student)# 一对多 多个学生
    subject=models.CharField('科目',max_length=20,default='')
    major=models.CharField('考卷适用专业',max_length=20)
    examtime=models.DateTimeField() # 开始时间
    stoptime=models.DateTimeField() # 结束时间

    class Meta:
        db_table='paper'
        verbose_name='试卷'
        verbose_name_plural=verbose_name
    def __str__(self):
        return self.major;

class Grade(models.Model):
    uuid = models.UUIDField(primary_key=True, verbose_name="uuid", auto_created=True, default=uuid.uuid4,
                            editable=False)
    sid=models.ForeignKey(Student,on_delete=models.CASCADE,default='')#添加外键
    subject=models.CharField('科目',max_length=20,default='')
    grade=models.IntegerField()

    def __str__(self):
        return '<%s:%s>'%(self.sid,self.grade);

    class Meta:
        db_table='grade'
        verbose_name='成绩'
        verbose_name_plural=verbose_name


class study_type(models.Model):
    uuid = models.UUIDField(primary_key=True, verbose_name="uuid", auto_created=True, default=uuid.uuid4,
                            editable=False)
    sid=models.ForeignKey(Student,on_delete=models.CASCADE,default='')#添加外键
    study1 = models.CharField('学习风格A',max_length=20,default='')
    study2 = models.CharField('学习风格R', max_length=20, default='')
    study3 = models.CharField('学习风格V', max_length=20, default='')
    study4 = models.CharField('学习风格K', max_length=20, default='')
    study_max = models.CharField('学习风格最大', max_length=20, default='')
    study_type = models.CharField('学习风格类型', max_length=20, default='')

    def __str__(self):
        return '<%s>'%(self.sid.name);

    class Meta:
        db_table='study_type'
        verbose_name='学习风格'
        verbose_name_plural=verbose_name



class study_Question(models.Model):
    paper = models.ForeignKey(Paper,on_delete=models.CASCADE, default='')
    sid = models.ForeignKey(Student,on_delete=models.CASCADE, default='')

    que = models.ForeignKey(Question,on_delete=models.CASCADE, default='')
    score = models.CharField("考题得分",max_length=10,default='0')
    def __str__(self):
        return f'{self.sid.name}'

    class Meta:
        db_table = 'study_Question'
        verbose_name = '考题评分'
        verbose_name_plural = verbose_name

class study_Knowledge1(models.Model):
    # 学生与知识点的关系
    uuid = models.UUIDField(primary_key=True, verbose_name="uuid", auto_created=True, default=uuid.uuid4,
                            editable=False)
    sid = models.ForeignKey(Student, on_delete=models.CASCADE, default='')  # 添加外键
    knowledge = models.ForeignKey(Knowledge1, on_delete=models.CASCADE, default='') #
    score = models.CharField("知识点评价",max_length=10,default='0')
    # 1为对完全掌握
    def __str__(self):
        return f'{self.sid.name}'

    class Meta:
        db_table = 'study_Knowledge1'
        verbose_name = '知识点评分'
        verbose_name_plural = verbose_name

class file_Input(models.Model):
    uuid = models.UUIDField(primary_key=True, verbose_name="uuid", auto_created=True, default=uuid.uuid4,
                            editable=False)
    user = models.ForeignKey(Teacher,on_delete=models.CASCADE)
    desc = models.TextField("文件描述",default="")
    name = models.CharField("文件名",max_length=100)
    img_file = models.ImageField(max_length=100, verbose_name="封面", upload_to="face/%Y/%m", default='')
    study_type = models.CharField("文件类型",max_length=10,default='学习风格A')
    Knowledge1s = models.ManyToManyField(Knowledge1)
    file = models.FileField("文件",max_length=255,upload_to="study_file/", default='')

    def __str__(self):
        return f'{self.name}'

    class Meta:
        db_table = 'file_Input'
        verbose_name = '学习文件资源管理'
        verbose_name_plural = verbose_name


class Article(models.Model):  # 定义文章模型类
    title = models.CharField(max_length=100, verbose_name='文章标题')  # verbose_name是
    content = models.TextField(verbose_name='题目')
    publish_time = models.DateTimeField(auto_now_add=True, verbose_name='发布时间')
    author = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='作者')
    question = models.TextField(verbose_name='答案')
    class Meta:
        db_table = 'article_tb'  # 定义表名
        verbose_name = '作业'  # 后台显示
        verbose_name_plural = verbose_name  # 后台显示的复数
    def __str__(self):
        return f'{self.title}'

class Comment(models.Model):  # 定义评论模型
    article = models.ForeignKey(to=Article, on_delete=models.CASCADE, verbose_name='评论文章')
    comment_content = models.TextField(verbose_name='评论内容')
    comment_author = models.ForeignKey(to=User, on_delete=models.CASCADE, verbose_name='评论者')
    comment_time = models.DateTimeField(auto_now_add=True, verbose_name='评论时间')
    pre_comment = models.ForeignKey('self', on_delete=models.CASCADE, null=True,
                                    verbose_name='父评论id',blank = True)  # 父级评论，如果没有父级则为空NULL, "self"表示外键关联自己

    class Meta:
        db_table = 'comment_tb'
        verbose_name = '作业回答记录'
        verbose_name_plural = verbose_name
    def __str__(self):
        return f'{self.comment_content}'

