import json
import random
import networkx as nx
import numpy as np
# from django.contrib.redirects.models import Redirect
from django.http import HttpResponse, JsonResponse,HttpResponseRedirect
from django.shortcuts import render, redirect
import pandas as pd
# Create your views here.
from django.urls import reverse
from gensim import corpora
from gensim.models.doc2vec import TaggedDocument, Doc2Vec

from .models import Rel, Student, Paper, Knowledge1, study_type, Question, Grade, study_Question, Teacher, \
    study_Knowledge1, Article, Comment, file_Input
from collections import defaultdict
from django.contrib.auth.models import User, Group
# 学生考试 的视图函数

# 初始化三元组数据
def init_rel_data():
    Knowledge1.objects.all().delete()
    Rel.objects.all().delete()
    data = pd.read_excel("data/数据结构与算法.xlsx", sheet_name="图谱").dropna()
    data_desc = pd.read_excel("data/数据结构与算法.xlsx", sheet_name="具体概念",names=['name','name_type','desc'])
    desc = defaultdict(str)
    for index, row in data_desc.iterrows():
        desc[row['name']] = row['desc']
    # print(desc)
    is_create = []
    kg = []
    for index, i in data[['sub_type', 'sub_name']].iterrows():
        if i['sub_name'] not in is_create:
            is_create.append(i['sub_name'])
            kg.append(Knowledge1(type=i["sub_type"], name=i['sub_name'], desc=desc.get(i['sub_name']),
                                 desc_all=desc.get(i['sub_name'])))

    for index, i in data[['obj_type', 'obj_name']].iterrows():
        if i['obj_name'] not in is_create:
            is_create.append(i['obj_name'])
            kg.append(Knowledge1(type=i["obj_type"], name=i['obj_name'], desc=desc.get(i['obj_name']),
                                 desc_all=desc.get(i['obj_name'])))

    Knowledge1.objects.bulk_create(kg)
    rel = []
    for index, i in data.iterrows():
        print(i['obj_name'],i['sub_name'])
        print(Knowledge1.objects.get(name=i['obj_name']))
        print(Knowledge1.objects.get(name=i['sub_name']))
        rel.append(Rel(obj_name=Knowledge1.objects.get(name=i['obj_name']),
                       sub_name=Knowledge1.objects.get(name=i['sub_name']),
                       rel_name=i['rel_name'], rel_type=i['rel_type']))
    Rel.objects.bulk_create(rel)

# 初始化学生信息
is_create = []
def init_user_info():
    print("go_here")
    User.objects.exclude(username="root").delete()
    Student.objects.all().delete()
    study_type.objects.all().delete()
    G_student = Group.objects.get(name="学生")
    table = pd.read_excel("data/学习风格 2.xlsx")
    # print(table)
    for index, row in table.iterrows():
        if row['序号'] not in is_create:
            is_create.append(row['序号'])
            # print(is_create,row['序号'])
            User.objects.create_user(username=row['序号'], email="", password="888888",is_staff=True)
            # u.is_staff = True
            u = User.objects.get(username=row['序号'])
            u.groups.add(G_student)

            s = Student(user=u, name=row['英文名'], class_name=row['班级'], sex=row['性别'], dept=row['爱好'], major=row['年级'])
            s.save()
            study_type(sid=s, study1=row['A总数'], study2=row['R总数'], study3=row['V总数'], study4=row['K总数'],
                       study_max=row['最高数'], study_type=row['风格类型']).save()

# 初始化考题
def init_exam_data():
    Question.objects.all().delete()
    table = pd.read_excel("data/测试题.xlsx")
    print(table)
    for index, row in table.iterrows():
        knowledge = row['考察知识点'].split(";")
        q = Question(subject="数据结构", title=row['题目'], optionA=row['选项A'],
                     optionB=row['选项B'], optionC=row['选项C'], optionD=row['选项D'],
                     answer=row['答案'], level=row['等级'], score=row['分数']
                     )
        q.save()
        q.Knowledge.set(Knowledge1.objects.filter(name__in=knowledge))


#

# init_user_info()
# init_rel_data()
# init_exam_data()

def django_to_table(keys=[]):
    table = []
    if not keys:
        for i in Rel.objects.all():
            table.append(
                [i.obj_name.type, i.sub_name.type, i.obj_name.desc, i.sub_name.desc, i.obj_name.name,i.sub_name.name,
                 i.rel_name, i.rel_type])
        table = pd.DataFrame(table,
                             columns=['obj_type', 'sub_type', 'obj_desc', 'sub_desc', 'obj_name', 'sub_name',
                                      'rel_name',
                                      'rel_type'])
    else:
        kk = list([i[0] for i in Knowledge1.objects.filter(uuid__in=keys).values_list('name')])
        print(kk)
        for i in Rel.objects.all():
            obj_type = i.obj_name.type
            sub_type = i.sub_name.type
            print(i.obj_name.name)
            print(i.sub_name.name)
            if i.obj_name.name in kk:
                obj_type = "错误点"
            if i.sub_name.name in kk:
                sub_type = "错误点"
            table.append(
                [obj_type, sub_type, i.obj_name.desc, i.sub_name.desc, i.obj_name.name, i.sub_name.name,
                 i.rel_name, i.rel_type])

        table = pd.DataFrame(table,
                             columns=['obj_type', 'sub_type', 'obj_desc', 'sub_desc', 'obj_name', 'sub_name',
                                      'rel_name',
                                      'rel_type'])
        print(len(table))
        table = table.drop_duplicates()
        return kk,table
    return table


# django_to_table()
# 考试页面
def startExam(request):
    if request.user.is_authenticated:
        sid = request.user
        # paper = Paper.objects.get(sid.objects.filter(user=sid))
        # print("找到该学生的试卷",paper)

        # # subject1=request.GET.get('subject')
        # subject1 = t.subject
        student = Student.objects.get(user=sid)
        paper = ""
        for p in student.paper_set.all():
            # if paper.objects # 这没做多试卷判断
            paper = p

        print('学号', sid, '考试科目', paper.subject)
        return render(request, 'exam.html', {'student': student, 'paper': [paper, ], 'subject': paper.subject})

# 用户考完提交
def calGrade(request):
    if request.method == 'POST':
        # 得到学号和科目
        # sid=request.POST.get('sid')
        try:
            subject1 = request.POST.get('subject')
            user = request.user
            # 重新生成Student实例，Paper实例，Grade实例，名字和index中for的一致，可重复渲染
            student = Student.objects.get(user=user)
            question = Paper.objects.filter(subject=subject1).values("pid").values('pid__uuid', 'pid__answer',
                                                                                   'pid__score')
            mygrade = 0
            ismygrade = False
            for p in question:
                qId = str(p['pid__uuid'])  # int 转 string,通过pid找到题号
                myans = request.POST.get(qId)  # 通过 qid 得到学生关于该题的作答
                if not study_Question.objects.filter(paper=Paper.objects.get(subject=subject1), sid__user=user,
                                                     que__uuid=qId):
                    if myans == p['pid__answer']:
                        study_Question.objects.create(paper=Paper.objects.get(subject=subject1), sid=student,
                                                      que=Question.objects.get(uuid=p['pid__uuid']),
                                                      score=p['pid__score']).save()
                        mygrade += p['pid__score']
                    else:
                        study_Question(paper=Paper.objects.get(subject=subject1), sid=student,
                                       que=Question.objects.get(uuid=p['pid__uuid']), score=0).save()
                else:
                    ismygrade = True
                    print("已经参与考试")
            if ismygrade:
                mygrade = 0
            if mygrade != 0:
                Grade.objects.create(sid=student, subject=subject1, grade=mygrade)
            return HttpResponse("计算完成")
        except Exception as e:
            return HttpResponse("无权访问")

# 雷达图
def radar_aqi(request):
    # 查看用户的学习特点
    print(request.user)
    try:
        s = study_type.objects.get(sid__user=request.user)
        return render(request, 'radar-aqi.html', context={
            'name': s.sid.name,
            'data': [int(s.study1), int(s.study2), int(s.study3), int(s.study4)],
        })
    except Exception:
        return HttpResponse("非学生账号")

# 知识图谱全局展示
def getalldata(request):
    if request.user.is_authenticated:
        print("this",request.user.is_authenticated)
        try:
            Student.objects.get(user=request.user)
            print("getalldata", request.user.username)
            sk = list(i[0] for i in
                      study_Knowledge1.objects.filter(sid__user__username=request.user.username, score=0).values_list(
                          'knowledge'))
            print(sk)
            _,data = django_to_table(sk)

        except Exception as e:
            print(e)
            data = django_to_table()

        data2 = make_json(data)
        return HttpResponse(json.dumps(data2), content_type='application/json')

# 知识图谱查询
def getdata(request):
    data = django_to_table()
    key_word = request.GET['key_word']
    query_type = request.GET['query_type']
    # print(key_word,query_type)
    if query_type == '1':
        data2, _ = find(data, key_word)
        data2 = make_json(data2)
    elif query_type == '2':
        data2, layel2node = find(data, key_word)
        t = [data2]
        for key_word2 in layel2node:
            data3, layel3node = find(data, key_word2)
            t.append(data3)
        t = pd.concat(t)
        data2 = t.drop_duplicates()
        data2 = make_json(data2)
    # print(data2)
    return HttpResponse(json.dumps(data2), content_type='application/json')

# 网络可视化
def networks(request):
    if not request.user.is_authenticated:
        print("没登录")
        return render(request, 'index.html')
    else:
        print("等录", request.user.username)
        return render(request, 'index.html')


def find(table, node, type="all"):
    """
    根据结点获取与之相邻的邻居
    """

    t1 = table[table['sub_desc'] == node]
    t1_child_node = t1['obj_desc'].values.tolist()
    t2 = table[table['obj_desc'] == node]
    t2_parent_node = t2['sub_desc'].values.tolist()
    if type == "all":
        t = pd.concat((t1, t2))
        t_node = list(set(t1_child_node + t2_parent_node))
    if type == "child":
        t = t1
        t_node = t1_child_node
    if type == "parent":
        t = t2
        t_node = t2_parent_node

    return t, t_node


def make_json(table):
    node_type = list(set(table['sub_type'].values.tolist() + table['obj_type'].values.tolist()))
    node_type_index = list([f"type_{i}" for i in range(len(node_type))])

    linknametype = list(set(table['rel_type'].values.tolist()))
    linkTypes = list([f"linetype_{i}" for i in range(len(linknametype))])
    link_index = [100000 + i for i in range(len(linkTypes))]

    node = list(set(table['sub_name'].values.tolist() + table['obj_name'].values.tolist()))
    edges = []
    for i, row in table.iterrows():
        edge = {
            "p": {
                "start": {
                    "identity": node.index(row['sub_name']),
                    "labels": [
                        node_type_index[(node_type.index(row['sub_type']))]
                    ],
                    "properties": {
                        "name": str(row['sub_name']),
                        "desc": str(row['sub_desc']),
                    }
                },
                "end": {
                    "identity": node.index(row['obj_name']),
                    "labels": [
                        node_type_index[(node_type.index(row['obj_type']))]
                    ],
                    "properties": {
                        "name": str(row['obj_name']),
                        "desc": str(row['obj_desc']),
                    }
                },
                "segments": [
                    {
                        "start": {
                            "identity": node.index(row['sub_name']),
                            "labels": [
                                node_type_index[(node_type.index(row['sub_type']))]
                            ],
                            "properties": {
                                "name": str(row['sub_name'])
                            }
                        },

                        "relationship": {
                            "identity": link_index[linknametype.index(row['rel_name'])],
                            "start": node.index(row['sub_name']),
                            "end": node.index(row['obj_name']),
                            "type": linkTypes[linknametype.index(row['rel_type'])],
                            "properties": {
                                "name": str(row['rel_name'])
                            }
                        },
                        "end": {
                            "identity": node.index(row['obj_name']),
                            "labels": [
                                node_type_index[(node_type.index(row['obj_type']))]
                            ],
                            "properties": {
                                "name": str(row['obj_name'])
                            }
                        },
                    }
                ],
                "length": 1.0
            }
        }
        edges.append(edge)
    return {
        "edges": edges,
        "names": node_type,
        "labels": node_type_index,
        "linkTypes": linkTypes
    }

# 认知分析
def dina(request):
    if request.user.is_authenticated:
        try:
            print(request.user)
            t = Teacher.objects.get(user=request.user)
            sqall = list(
                study_Question.objects.filter(paper=Paper.objects.get(tid=t)).values_list('sid__user__username',
                                                                                          'que__uuid',
                                                                                          'score'))  # 找到当前老师的考题答案
            print(sqall)
            Xtable = pd.DataFrame(sqall, columns=['user', 'qid', 'score']).drop_duplicates(subset=['user', 'qid'])
            print(Xtable)
            Xtable = Xtable.pivot(index='user', columns='qid', values='score')  # 学生考试矩阵
            p = Paper.objects.get(tid=t)
            question_knowledge = []
            for i in p.pid.all():
                for j in i.Knowledge.all():
                    print("pid", j)
                    question_knowledge.append([i.uuid, j.uuid, 1])
            print("question_knowledge",question_knowledge)

            qk = pd.DataFrame(question_knowledge, columns=['question', 'knowledge', 'score'])
            qk = qk.pivot(index='question', columns='knowledge', values='score')
            qk = qk.fillna(0)

            Xtable = Xtable[qk.index]
            user_index = Xtable.index
            question_index = Xtable.columns
            knowledge_index = qk.columns
            Xtable = Xtable.astype(int)
            qk = qk.astype(int)
            print("ggggg",Xtable, qk)

            data2 = np.matmul(Xtable.values,qk.values)
            data2 = pd.DataFrame(data2, index=user_index, columns=knowledge_index)

            km = KMeans(n_clusters=6)
            print(data2.values)
            km.fit(data2.values)
            clusters = km.labels_.tolist()
            data2['user'] = data2.index
            print(data2)

            data2 = data2.melt(id_vars='user')
            for index, row in data2.iterrows():
                study_Knowledge1.objects.create(sid=Student.objects.get(user__username=row['user']),
                                                knowledge=Knowledge1.objects.get(uuid=row['knowledge']),
                                                score=row['value'])
            items = []
            for i, j in zip(data2['user'].values.tolist(), clusters):
                # print(Student.objects.get(user__username=i).name,j)
                print(i)
                items.append({"name": Student.objects.get(user__username=i).name, "type": j})
            items = sorted(items, key=(lambda x: x["type"]))
            print(items)

            return render(request, 'group.html', {'items': items})
        except Exception as e:
            raise e
            return HttpResponse("非教师权限访问")


# 评论

user_names = {}
user_types = {}
for i in Teacher.objects.all():
    user_names[i.user.username] = i.name
    user_types[i.user.username] = "教师"
for i in Student.objects.all():
    user_names[i.user.username] = i.name
    user_types[i.user.username] = "学生"

# 留言系统（作业）
def article_index(request):
    if request.user.username:  # 判断用户是否已登录（用户名是否存在）
        all_article_list = Article.objects.all()  # 取出所有的文章对象，结果返回一个QuerySet[]对象
        context = {
            'all_article_list': all_article_list,
            'user_names': user_names
        }
        return render(request, 'article_index.html', context=context)  # 返回首页的页面，并将文章对象传到模板进行渲染
    else:
        return redirect('/user_login/')  # 如果用户没有登录，则跳转至登录页面


def article_detail(request, article_id):
    if request.user.username:
        article = Article.objects.get(id=article_id)  # 从数据库找出id=article_id的文章对象
        Comment
        comment_list = Comment.objects.filter(article_id=article_id)  # 从数据库找出该文章的评论数据对象
        context = {
            'article': article,
            'comment_list': comment_list,
            'user_names': user_names,
            'user_types': user_types,
        }
        print("zz",context)
        return render(request, 'article_detail.html', context=context)  # 返回对应文章的详情页面
    else:
        return redirect('/user_login/')


def comment_control(request):  # 提交评论的处理函数

    if request.user.username:
        comment_content = request.POST.get('comment_content')
        article_id = request.POST.get('article_id')
        pid = request.POST.get('pid')
        author_id = request.user.id  # 获取当前用户的ID

        Comment.objects.create(comment_content=comment_content, pre_comment_id=pid, article_id=article_id,
                               comment_author_id=author_id)  # 将提交的数据保存到数据库中

        article = list(
            Comment.objects.values('id', 'comment_content', 'pre_comment_id', 'article_id', 'comment_author_id',
                                   'comment_time'))  # 以键值对的形式取出评论对象，并且转化为列表list类型

        return JsonResponse(article, safe=False)  # JsonResponse返回JSON字符串，自动序列化，如果不是字典类型，则需要添加safe参数为False
    else:
        return redirect('/user_login/')

# 用户知识点推荐
def sort_key(request):
    try:
        sid = Student.objects.get(user=request.user)

        sk = list(i[0] for i in
                  study_Knowledge1.objects.filter(sid=sid,score=0).values_list('knowledge'))
        print("sk", sk, sid)
        if sk:
            print("sk", sk)
            kk,rel = django_to_table(sk)
            G = [(row['sub_name'], row['obj_name']) for i, row in rel.iterrows()]
            DG = nx.DiGraph(G)
            sorts = list(nx.topological_sort(DG))
            sorts = [i for i in sorts if i in kk]
            context = {
                "sorts": sorts,
            }
            return render(request, 'file_show2.html', context=context)
        else:
            all_file_list = file_Input.objects.all()  # 取出所有的文章对象，结果返回一个QuerySet[]对象
            # print(all_file_list)
            context = {
                'pics': all_file_list,
            }
            return HttpResponse("非法访问")  # 返回首页的页面，并将文章对象传到模板进行渲染
    except Exception as e:
        raise e
        all_file_list = file_Input.objects.all()  # 取出所有的文章对象，结果返回一个QuerySet[]对象
        context = {
            'pics': all_file_list,
        }
        return HttpResponse("非法访问")  # 返回首页的页面，并将文章对象传到模板进行渲染
# 学习资料展示
def file_show(request):

    all_file_list = file_Input.objects.all()  # 取出所有的文章对象，结果返回一个QuerySet[]对象
    # print(all_file_list)
    context = {
        'pics': all_file_list,
    }
    return render(request, 'file_show.html', context=context)  # 返回首页的页面，并将文章对象传到模板进行渲染
# 学生信息展示
def student_info(request):
    if request.user.username:
        S = Student.objects.get(user=request.user)
        if S:
            return render(request, 'student_info.html', context={"student": S})
        else:
            return HttpResponse("非学生账号")


import jieba
from gensim import corpora, models, similarities
from sklearn.cluster import KMeans


# def fit_predict(base_data, test_text):
#
#     # 1.将base_data中的数据进行遍历后分词
#     base_items = [[i for i in jieba.lcut(item)] for item in base_data]
#     # print(base_items)
#
#     # 2.生成词典
#     dictionary = corpora.Dictionary(base_items)
#     # 3.通过doc2bow稀疏向量生成语料库
#     corpus = [dictionary.doc2bow(item) for item in base_items]
#     # 4.通过TF模型算法，计算出tf值
#     tf = models.TfidfModel(corpus)
#     # 5.通过token2id得到特征数（字典里面的键的个数）
#     num_features = len(dictionary.token2id.keys())
#     # 6.计算稀疏矩阵相似度，建立一个索引
#     index = similarities.MatrixSimilarity(tf[corpus], num_features=num_features)
#
#     # 7.处理测试数据
#     # test_text = "风雨凄凄，鸡鸣喈喈。既见君子，云胡不夷。风雨潇潇，鸡鸣胶胶。既见君子，云胡不瘳。风雨如晦，鸡鸣不已。既见君子，云胡不喜。"
#     test_words = [word for word in jieba.cut(test_text)]
#     # print(test_words)
#
#     # 8.新的稀疏向量
#     new_vec = dictionary.doc2bow(test_words)
#     # 9.算出相似度
#     sims = index[tf[new_vec]]
#     # print(list(sims))
#     return sims


def kmeans(base_data, class_n=2):
    # 1.将base_data中的数据进行遍历后分词
    base_items = [" ".join([i for i in jieba.lcut(item)]) for item in base_data]
    sentenceLabeled = []
    # print(base_items)
    for sentenceID, sentence in enumerate(base_items):
        sentenceL = TaggedDocument(words=sentence.split(), tags=['SENT_%s' % sentenceID])
        sentenceLabeled.append(sentenceL)
    model = Doc2Vec(vector_size=300, window=10, min_count=0, workers=11, alpha=0.025,
                    min_alpha=0.025)
    model.build_vocab(sentenceLabeled)

    model.train(sentenceLabeled, total_examples=model.corpus_count, epochs=20)

    textVect = model.dv.get_normed_vectors()
    # print(textVect)
    km = KMeans(n_clusters=class_n)
    km.fit(textVect)
    clusters = km.labels_.tolist()
    cluster_info = {'sentence': base_data, 'cluster': clusters}
    sentenceDF = pd.DataFrame(cluster_info, columns=['sentence', 'cluster'])
    return sentenceDF


# def article_predict(request):
#     if request.user.is_authenticated:
#         try:
#             allgroups = []
#             t = Teacher.objects.get(user=request.user)
#             for j in Article.objects.filter(author=request.user):
#                 #base_data = list(Comment.objects.filter(article=j).values_list('comment_content',flat=True))
#                 student_user = Comment.objects.filter(article=j)
#                 base_data = []
#                 base_user = []
#                 base_user2 = []
#
#                 for i in student_user :
#                     if i.comment_author not in base_user2:
#                         bd = Comment.objects.filter(comment_author=i.comment_author,article=j).values_list('comment_content',flat=True)
#                         base_data.append(" ".join(bd))
#                         base_user.append(i)
#                         base_user2.append(i.comment_author)
#                 print(len(base_user))
#                 question = j.question
#                 # score = fit_predict(base_data,question)
#                 user_type = kmeans(base_data,class_n = 2)
#                 # print(score)
#                 # print(user_type)
#                 student_user = Comment.objects.filter(article=j)
#                 student_users = []
#
#                 for i in base_user:
#                     try:
#                         s = Student.objects.get(user=i.comment_author)
#                         student_users.append(s.name)
#                     except:
#                         # 老师回答
#                         pass
#                 user_types = user_type['cluster'].values.tolist()
#                 groups = {}
#                 for im,jm,km in zip(student_users,base_data,user_types):
#                     allgroups.append({'title':j.title,'name':im,'que':jm,'group':km})
#             print(allgroups)
#             return render(request, 'group.html', {'items':allgroups})
#
#         except Exception as e:
#             raise e
#             return HttpResponse("非教师权限访问")


# 4张统计
def plot_student_scores(request):
    t = pd.DataFrame(Grade.objects.values())
    t2 = pd.DataFrame(study_type.objects.values())
    print(t.columns)
    print(t2.columns)
    t3 = pd.merge(left=t,right=t2,left_on='sid_id',right_on='sid_id')
    print(t3)
    m = t.groupby('grade', as_index=False)['uuid'].count()
    m2 = t3.groupby('study_type', as_index=False)['grade'].mean()

    bins = [0,18,30]
    labels = ['不及格','及格']
    t['Grade2'] = pd.cut(t['grade'], bins=bins, labels=labels)
    m3 = t.groupby('Grade2',as_index=False)['uuid'].count()
    print(m)
    student_scores = []
    for i, j in m.iterrows():
        student_scores.append({"name": str(j['grade']) + "分", "score": j['uuid']})
    student_scores2 = []
    for i, j in m2.iterrows():
        student_scores2.append({"name": str(j['study_type']), "score": j['grade']})
    student_scores3 = []
    for i, j in m3.iterrows():
        student_scores3.append({"name": str(j['Grade2']), "score": j['uuid']})
    student_scores4 = []
    for i, j in t3.iterrows():
        student_scores4.append({"name": j['study_max'], "score": j['grade'], "grade": j['study_type']})


    return render(request, template_name="daping.html",context={"data1":student_scores,"data2":student_scores2,"data3":student_scores3,'data4':student_scores4})

# 随机
def random_kaoshi():
    # 随机考试
    pid = Paper.objects.get(tid=Teacher.objects.get(user__username="root")).pid
    sid = Paper.objects.get(tid=Teacher.objects.get(user__username="root")).sid
    ss = []
    gs = []
    for j in sid.values('uuid'):
        scores = 0
        for i in pid.values('uuid'):
            score = random.randint(0, 1)
            scores += score
            s = study_Question(paper=Paper.objects.get(tid=Teacher.objects.get(user__username="root")),
                               sid=Student.objects.get(uuid=j['uuid']),
                               que=Question.objects.get(uuid=i['uuid']),
                               score=score)

            ss.append(s)
        g = Grade(sid=Student.objects.get(uuid=j['uuid']), subject="数据结构与算法", grade=scores)
        print(g)
        gs.append(g)

    study_Question.objects.bulk_create(ss)
    Grade.objects.bulk_create(gs)
# random_kaoshi()

def regist(request):
    if request.method == 'GET':
        return render(request, "regist.html")
    else:
        try:
            userid = request.POST['id']
            userpw = request.POST['pw']
            useremail = request.POST['email']
            username = request.POST['name']
            usersex = request.POST['sex']
            usersr = request.POST['sr']
            userage = request.POST['age']
            userpn = request.POST['phonenum']
        except Exception as e:
            raise e
            render(request, "regist.html")
        try:
            G_user = Group.objects.get(name="学生")
            user = User.objects.create_user(username=userid,
                                            password=userpw,
                                            email=useremail, is_staff=True)
            user.groups.add(G_user)
            user.save()
            try:
                Users.objects.create(user=user,
                                     name=username,
                                     class_name=usersex,
                                     sex=userage,
                                     dept=usersr,
                                     major=userpn).save()

                return HttpResponseRedirect('/admin/')
            except Exception as e:
                raise e
                print(e)
                return HttpResponse("regist fail")
            return render(request, "regist.html")
        except Exception as e:
            print(e)
            return render(request, "regist.html")
